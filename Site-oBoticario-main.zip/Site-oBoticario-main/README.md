# Criação de um site para a marca O Boticário.
### Trabalho para a disciplia de Projetos do curso Análise e Desenvolvimento de Sistemas - 2º semestre de 2023.
---
[Acesse o site clicando aqui](https://guilherme-neves1.github.io/Site-oBoticario/)
*Página 1*
![Página-1](https://github.com/Guilherme-Neves1/Site-oBoticario/blob/main/_imagens/Print01.png?raw=true)
*Página 2*
![Página-2](https://github.com/Guilherme-Neves1/Site-oBoticario/blob/main/_imagens/Print02.png?raw=true)
*Página 3*
![Página-3](https://github.com/Guilherme-Neves1/Site-oBoticario/blob/main/_imagens/Print03.png?raw=true)
*Página 4*
![Página-4](https://github.com/Guilherme-Neves1/Site-oBoticario/assets/142439062/c897d121-9df8-40ee-8523-cf71711af4d1)
*Página 5*
![Página-5](https://github.com/Guilherme-Neves1/Site-oBoticario/assets/142439062/f826ebf1-94e0-481e-a2ed-8565ee0c9bdf)
